/* EJERCICIO: u3e10_window */
/*
Crea un programa que tenga botones para permitir modificar las siguientes propiedades de una ventana:
● Abrir una ventana nueva:
	- Debes preguntar al usuario si está de acuerdo o no, y solo si aceptase abrirá la nueva ventana.
	- La nueva ventana tendrá las siguientes propiedades: 
		no tendrá barra de herramientas, 
		ni location, 
		ni barra de menú, 
		ni será redimensionable. 
		Tendrá 200x80píxeles 
		y se posicionará en 500x500píxeles.
	- La nueva ventana incluirá un pequeño texto y un botón que al hacer clic cerrará la ventana.
Todos los botones,exceptoel primero y el segundo,los puedes programar directamente mediante la propiedad onClick, por ejemplo:
– <input type=“button” value=“Imprimir” onClick=“print()”/>
Recuerda que no es necesario utilizar “window” delante de la propiedad.
*/

function ej101() {
}

/*
● Cerrar la ventana creada: si la ventana está cerrada mostrará un mensaje de error.
*/
function ej102() {
}

/*
● Mover la ventana 10 píxeles a la derecha y abajo.
*/
function ej103() {
}

/*
● Mover la ventana a la posición 100,100.
*/
function ej104() {
}

/*
● Aumentar el tamaño de la ventana 10 píxeles de ancho y largo.
*/
function ej105() {
}

/*
● Aumentar el tamaño de la ventana a 400x200.
*/
function ej106() {
}

/*
● Colocar el scroll de la ventana arriba del todo
*/
function ej107() {
}

/*
● Colocar el scroll de la ventana a 10 píxeles de la parte superior.
*/
function ej108() {
}
